﻿using System;

namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Library l = new Library("National", "Dhaka");
            Contact c1 = new Contact("Sanjida", "191", "0175000000");
            Mobile m1 = new Mobile("GP", "50.88", "0175000000", "Sanjida");
            Course c2 = new Course();
            c2.CourseName = "OOP2";
            c2.CourseCode = "002";
            c2.CourseCredit = 3;

            c2.ShowCourseinfo();


            l.ShoewInfo();
            Console.WriteLine();

            c1.ShoewInfo();
            Console.WriteLine();
            Book b1 = new Book("c++", "007", "coding", 10);
            Book b2 = new Book("c#", "123", "dev", 20);

            l.AddNewBook(b1, b2);
            l.ShowAllBooks();
            m1.ShoewInfo();
        }
    }
}
