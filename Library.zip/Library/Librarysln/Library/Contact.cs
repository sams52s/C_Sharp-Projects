﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    class Contact
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        private string mobileNumber;

        public string MobileNumber
        {
            get { return mobileNumber; }
            set { mobileNumber = value; }
        }
        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public Contact()
        {

        }
        public Contact(string name, string id, string mobileNumber)
        {
            this.name = name;
            this.id = id;
            this.mobileNumber = mobileNumber;
        }
        public void ShoewInfo()
        {
            Console.WriteLine("Name : " + name);
            Console.WriteLine("Id : " + id);
            Console.WriteLine("Department : " + mobileNumber);
        }



    }
}
