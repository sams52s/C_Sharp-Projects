﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    class Mobile
    {
       private String mobileOwnerName;
       private String mobileNumber;
       private String mobileBalance;
       private String mobileOSName;

        public string MobileOwnerName
        {
            get
            {
                return mobileOwnerName;
            }
            set
            {
                mobileOwnerName = value;

            }
        }
        public string MobileNumber
        {
            get
            {
                return mobileNumber;
            }
            set
            {
                mobileNumber = value;

            }
        }
        public string MobileBalance
        {
            get
            {
                return mobileBalance;
            }
            set
            {
                mobileBalance = value;

            }
        }
        public string MobileOSName
        {
            get
            {
                return mobileOSName;
            }
            set
            {
                mobileOSName = value;

            }
        }

        public Mobile() { }
        public Mobile(string mn,string mb, string mnum,string mown) {
            this.mobileOSName = mn;
            this.mobileBalance = mb;

            this.mobileNumber = mnum;
            this.mobileOwnerName = mown;
        }
        public void ShoewInfo()
        {
            Console.WriteLine("Name : " + mobileOSName);
            Console.WriteLine("MobileBalance : " + mobileBalance);
            Console.WriteLine("MobileNumber : " + mobileNumber);
            Console.WriteLine("MobileOwnerName : " + mobileOwnerName);
        }

    }
}
