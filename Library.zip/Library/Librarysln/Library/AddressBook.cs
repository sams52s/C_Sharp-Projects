﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    class AddressBook
    {
      private  String ownerName;
      private  String info;
      private  Contact[] listOfContact;
        public AddressBook() { }
        public AddressBook(string on,string i)
        {
            ownerName = on;
            info = i;
        }
        void ShowAllContactInfo() { 
            Console.WriteLine("Book: " + listOfContact);
        }
void AddContact(Contact con) { 
            

        }
void DeleteContact(Contact con) {
        }
    }
}
